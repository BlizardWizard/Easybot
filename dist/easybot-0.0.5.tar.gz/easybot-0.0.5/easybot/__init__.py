from easybot.easybot import joke
from easybot.easybot import foo
from easybot.easybot import ping
