def joke():
    return "Hello World"


def foo():
    return "bar"


def ping():
    return "pong"
