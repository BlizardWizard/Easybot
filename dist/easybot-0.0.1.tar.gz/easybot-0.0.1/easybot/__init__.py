def joke():
    return "Hello World"
