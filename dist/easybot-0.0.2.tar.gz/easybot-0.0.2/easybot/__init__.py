from easybot.easybot import joke
