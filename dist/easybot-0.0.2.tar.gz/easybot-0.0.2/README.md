# Easybot
Library for easily creating Discord bots with Python
